<template>
    <div class="bg-white border border-gray-200 rounded-lg shadow-lg">
        <slot />
    </div>
</template>