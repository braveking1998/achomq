<template>
    <div class="bg-gray-200 pt-10 border-t-4 border-t-blue-950 basis-36 text-base text-center hover:bg-purple-400 hover:border-t-red-800">
        <slot>User's name</slot>
    </div>
</template>