<template>
    <form>
        <div class="flex h-8">
            <button type="submit" class="bg-gray-600 text-blue-dark font-extrabold px-2"><font-awesome-icon :icon="['fas', 'search']" /></button>
            <input type="text" id="search" placeholder="به دنبال چه چیزی می گردید" class="placeholder:text-sm border-0"/>
        </div>
    </form>
</template>