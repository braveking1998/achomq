<?php

namespace App\Http\Middleware;

use App\Models\ProfileImage;
use Illuminate\Http\Request;
use Inertia\Middleware;
use Tightenco\Ziggy\Ziggy;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root template that is loaded on the first page visit.
     *
     * @var string
     */
    protected $rootView = 'app';

    /**
     * Determine the current asset version.
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Define the props that are shared by default.
     *
     * @return array<string, mixed>
     */
    public function share(Request $request): array
    {
        $selectedImage = ($request->user()) ? ProfileImage::find($request->user()->profile_image) : false;

        return [
            ...parent::share($request),
            'auth' => [
                'user' => $request->user(),
                'selectedImage' => $selectedImage,
                'level' => $request->user()->level ?? false,
            ],
            'flash' => [
                'success' => $request->session()->get('success'),
            ],
            'ziggy' => fn () => [
                ...(new Ziggy)->toArray(),
                'location' => $request->url(),
            ],
        ];
    }
}
